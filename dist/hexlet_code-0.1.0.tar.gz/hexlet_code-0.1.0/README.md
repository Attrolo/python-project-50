### Hexlet tests and linter status:
[![Actions Status](https://github.com/Attrolo/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Attrolo/python-project-50/actions)

___Hello! It's my second project.___

***
### 
***Difference calculator, compares 2 files and shows differences between them***
###

***

_**To call help, use the command: gendiff -h*_
<a href="https://asciinema.org/a/ji8kI9pqNLlNnHdyhJctoQZF9" target="_blank"><img src="https://asciinema.org/a/ji8kI9pqNLlNnHdyhJctoQZF9.svg" /></a>

***

_*To compare 2 files, use the command: gendiff filepath1.json filepath2.json*_

<a href="https://asciinema.org/a/gWQwy1N7hyi6J0wksNeJOzaLB" target="_blank"><img src="https://asciinema.org/a/gWQwy1N7hyi6J0wksNeJOzaLB.svg" /></a>

***
