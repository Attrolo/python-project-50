# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Attrolo/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Attrolo/python-project-50/actions)\n\n___Hello! It\'s my second project.___\n\n***\n### \n***Difference calculator, compares 2 files and shows differences between them***\n###\n\n***\n\n_**To call help, use the command: gendiff -h*_\n<a href="https://asciinema.org/a/ji8kI9pqNLlNnHdyhJctoQZF9" target="_blank"><img src="https://asciinema.org/a/ji8kI9pqNLlNnHdyhJctoQZF9.svg" /></a>\n\n***\n\n_*To compare 2 files, use the command: gendiff filepath1.json filepath2.json*_\n\n<a href="https://asciinema.org/a/gWQwy1N7hyi6J0wksNeJOzaLB" target="_blank"><img src="https://asciinema.org/a/gWQwy1N7hyi6J0wksNeJOzaLB.svg" /></a>\n\n***\n',
    'author': 'Attrolo',
    'author_email': 'yurin-d@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
